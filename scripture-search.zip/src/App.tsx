import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Compass, 
  Heart, 
  Sparkles, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Bookmark, 
  Trash2, 
  FileCode, 
  BookMarked,
  HelpCircle,
  X,
  Plus,
  PenSquare,
  Sparkle,
  Share2,
  Sun,
  Moon,
  Atom,
  ExternalLink
} from 'lucide-react';
import { ScriptureResult, ReligionFilter, SavedScriptureItem } from './types';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';

// sugerested search terms in Bengali with English description
const suggestions = [
  { text: 'ধৈর্য', subtitle: 'Patience' },
  { text: 'ক্ষমা', subtitle: 'Forgiveness' },
  { text: 'দান', subtitle: 'Charity / Giving' },
  { text: 'ক্রোধ', subtitle: 'Anger / Wrath' },
  { text: 'সীরাত', subtitle: 'Prophet Seerah' },
  { text: 'পিতামাতা', subtitle: 'Parents' },
  { text: 'অহংকার', subtitle: 'Pride / Arrogance' },
  { text: 'সত্যবাদিতা', subtitle: 'Truthfulness' }
];

// Sample featured scripture data to make the landing page beautiful
const localFeaturedScriptures: ScriptureResult[] = [
  {
    id: 'f1',
    religion: 'Islam',
    topic: 'ধৈর্য এবং স্বস্তি',
    source_chapter: 'সূরা আল-বাকারা (Quran)',
    reference_number: '২:১৫৩',
    arabic_text: 'يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',
    arabic_pronunciation: 'ইয়া আইয়্যুহাল্লাযীনা আমানুসতাঈনূ বিসবরি ওয়াস্‌সালাহ‌্, ইন্নাল্লাহা মা’আস সাবেরীন',
    verse_text: 'হে ঈমানদারগণ! তোমরা ধৈর্য ও সালাতের মাধ্যমে সাহায্য প্রার্থনা কর। নিশ্চয়ই আল্লাহ ধৈর্যশীলদের সাথে আছেন।',
    context_explanation: 'যেকোনো কঠিন অবস্থায় চরম হতাশাগ্রস্ত না হয়ে ধৈর্য ধারণ করা এবং স্রষ্টার প্রতি অবিচল আস্থা রাখার দিকনির্দেশনা দেয় এই বাণী।',
    reference_link: 'https://quran.com/2/153'
  },
  {
    id: 'f2',
    religion: 'Sanatan',
    topic: 'কর্তব্য ও কর্মযোগ',
    source_chapter: 'শ্রীমদ্ভগবদ্গীতা অধ্যায় ২ (Gita)',
    reference_number: 'শ্লোক ৪৭',
    verse_text: 'কর্মণ্যেবাধিকারস্তে মা ফলেষু কদাচন। মা কর্মফলহেতুর্ভুর্মা তে সঙ্গোঽস্ত্বকর্মণি॥',
    context_explanation: 'প্রতিটি মানুষের দায়িত্ব হলো ফলের আশা না করে নিজের কর্তব্যকে নিষ্ঠার সাথে পালন করা। প্রত্যাশাহীন কাজ মানসিক শান্তি আনয়ন করে।',
    reference_link: 'https://www.holy-bhagavad-gita.org/chapter/2/verse/47'
  },
  {
    id: 'f3',
    religion: 'Christianity',
    topic: 'প্রেম ও ক্ষমাশীলতা',
    source_chapter: 'মথি ৫ (Bible)',
    reference_number: '৫:৪৪',
    verse_text: 'কিন্তু আমি তোমাদিগকে বলিতেছি, তোমাদের শত্রুরদিগকে প্রেম করিও, এবং যাহারা তোমাদের তাড়না করে, তাহাদের জন্য প্রার্থনা করিও।',
    context_explanation: 'হিংসা ও ক্রোধের বিরুদ্ধে দাঁড়িয়ে শত্রুভাবাপন্নদের প্রতিও দয়াশীল হওয়া এবং ক্ষমার মানসিকতা লালন করার তাগিদ দেয় যীশুর এই মহান বাণী।',
    reference_link: 'https://www.biblegateway.com/passage/?search=Matthew+5%3A44&version=BENGALI'
  },
  {
    id: 'f4',
    religion: 'Buddhism',
    topic: 'অহিংসা ও চিরন্তন নিয়ম',
    source_chapter: 'ধম্মপদ - যমকবগ্গ (Dhammapada)',
    reference_number: 'গাথা ৫',
    verse_text: 'বৈরিতা বা হিংসা দিয়ে হিংসা কখনো প্রশমিত হয় না। অহিংসা বা অবৈরিতা দ্বারাই হিংসা প্রশমিত হয়; এটাই ধরণীর চিরন্তন সত্য ও নিয়ম।',
    context_explanation: 'ক্রোধ ও শত্রুতাকে পাল্টা হিংসা দিয়ে শেষ করা যায় না; শুধু ক্ষমা ও ভালোবাসার মাধ্যমেই চরম শান্তি এবং অহিংসা প্রতিষ্ঠা করা সম্ভব।',
    reference_link: 'https://www.tipitaka.org/'
  }
];

const flutterSourceCode = `import 'dart:convert';
import 'package:flutter/material';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MultiFaithScriptureApp());
}

class MultiFaithScriptureApp extends StatelessWidget {
  const MultiFaithScriptureApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ঐশী বাণী অনুসন্ধান',
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF5A5A40),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5A5A40),
          primary: const Color(0xFF5A5A40),
          secondary: const Color(0xFFC5A059),
        ),
      ),
      home: const ScriptureHomeScreen(),
    );
  }
}

class ScriptureHomeScreen extends StatefulWidget {
  const ScriptureHomeScreen({super.key});

  @override
  State<ScriptureHomeScreen> createState() => _ScriptureHomeScreenState();
}

class _ScriptureHomeScreenState extends State<ScriptureHomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedFilter = 'all';
  List<dynamic> _results = [];
  bool _isLoading = false;
  String? _errorMessage;

  // Replace with your actual live host URL
  final String _backendBaseUrl = 'https://YOUR_APP_LOCKED_DOMAIN_OR_URL';

  Future<void> _fetchScriptures(String query) async {
    if (query.trim().isEmpty) return;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final response = await http.post(
        Uri.parse('$_backendBaseUrl/api/search'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'query': query,
          'religion': _selectedFilter,
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        setState(() {
          _results = data['results'] ?? [];
        });
      } else {
        setState(() {
          _errorMessage = 'বাণী পেতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'নেটওয়ার্ক সংযোগ ত্রুটি। ব্যাকএন্ড সচল আছে কিনা তা নিশ্চিত করুন।';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F0),
      appBar: AppBar(
        title: const Text('ঐশী বাণী অনুসন্ধান', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF5A5A40),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'যেকোনো বিষয় লিখুন (যেমন: ক্ষমা, দান, ধৈর্য)...',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () => _fetchScriptures(_searchController.text),
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildFilterButton('all', 'সব ধর্ম'),
                _buildFilterButton('islam', 'ইসলাম'),
                _buildFilterButton('sanatan', 'সনাতন'),
                _buildFilterButton('christianity', 'খ্রিষ্ট'),
              ],
            ),
            const SizedBox(height: 16),
            if (_isLoading)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else if (_errorMessage != null)
              Expanded(child: Center(child: Text(_errorMessage!, style: const TextStyle(color: Colors.red))))
            else
              Expanded(
                child: _results.isEmpty
                    ? const Center(child: Text('কোনো বাণী খোঁজা হয়নি'))
                    : ListView.builder(
                        itemCount: _results.length,
                        itemBuilder: (context, index) {
                          final item = _results[index];
                          return Card(
                            color: Colors.white,
                            margin: const EdgeInsets.only(bottom: 12),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['religion'] ?? '',
                                    style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFC5A059)),
                                  ),
                                  const SizedBox(height: 8),
                                  Text('"$item"'),
                                  const SizedBox(height: 8),
                                  Text('— \${item["source_chapter"]} (\${item["reference_number"]})'),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              )
          ],
        ),
      ),
    );
  }

  Widget _buildFilterButton(String filter, String label) {
    final isSelected = _selectedFilter == filter;
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected ? const Color(0xFF5A5A40) : Colors.white,
        foregroundColor: isSelected ? Colors.white : Colors.black87,
      ),
      onPressed: () {
        setState(() {
          _selectedFilter = filter;
        });
      },
      child: Text(label),
    );
  }
}
`;

interface JournalStatsChartProps {
  savedItems: SavedScriptureItem[];
  darkMode?: boolean;
}

function JournalStatsChart({ savedItems, darkMode }: JournalStatsChartProps) {
  const counts = {
    Islam: 0,
    Sanatan: 0,
    Christianity: 0,
    Buddhism: 0
  };

  savedItems.forEach(item => {
    if (item.religion === 'Islam') counts.Islam++;
    else if (item.religion === 'Sanatan') counts.Sanatan++;
    else if (item.religion === 'Christianity') counts.Christianity++;
    else if (item.religion === 'Buddhism') counts.Buddhism++;
  });

  const total = savedItems.length || 1;

  const chartData = [
    { 
      name: 'ইসলাম', 
      count: counts.Islam, 
      percentage: Math.round((counts.Islam / total) * 100),
      color: '#10b981',
      emoji: '🕌'
    },
    { 
      name: 'সনাতন', 
      count: counts.Sanatan, 
      percentage: Math.round((counts.Sanatan / total) * 100),
      color: '#d97706',
      emoji: '🕉️'
    },
    { 
      name: 'খ্রিষ্টধর্ম', 
      count: counts.Christianity, 
      percentage: Math.round((counts.Christianity / total) * 100),
      color: '#e11d48',
      emoji: '✝️'
    },
    { 
      name: 'বৌদ্ধধর্ম', 
      count: counts.Buddhism, 
      percentage: Math.round((counts.Buddhism / total) * 100),
      color: '#f59e0b',
      emoji: '☸️'
    }
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white/95 backdrop-blur-md p-3.5 border border-sage/15 rounded-2xl shadow-xl font-sans text-xs">
          <p className="font-bold text-sage flex items-center gap-1.5 mb-1 text-[13px]">
            <span>{data.emoji}</span>
            <span>{data.name}</span>
          </p>
          <div className="space-y-0.5 text-zinc-600 font-medium">
            <p>মোট সংরক্ষিত: <span className="text-sage font-bold font-serif">{data.count} টি</span></p>
            <p>অনুপাত: <span className="text-gold font-bold font-serif">{data.percentage}%</span></p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-[32px] border border-sage/15 p-6 md:p-8 shadow-3xs hover:shadow-xs transition-colors relative overflow-hidden">
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-gold/5 rounded-full blur-2xl pointer-events-none" />
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
        <div className="lg:col-span-5 space-y-4">
          <div>
            <span className="text-[10px] font-bold text-gold tracking-wider uppercase bg-gold/10 px-2.5 py-1 rounded-full border border-gold/15">
              জার্নাল সামারি ড্যাশবোর্ড
            </span>
            <h4 className="text-lg font-bold text-sage font-serif mt-2.5">
              ধর্মীয় উৎস ভিত্তিক প্রতিফলন বিশ্লেষণ
            </h4>
            <p className="text-xs text-warm-text/75 mt-1 leading-relaxed">
              আপনার সংগ্রহে থাকা সর্বমোট <span className="font-serif font-bold text-sage">{savedItems.length} টি</span> অমূল্য বাণীর বিভাজন ও নিয়মিত অনুধাবনের হার।
            </p>
          </div>

          <div className="space-y-2 pt-1">
            {chartData.map((data) => {
              return (
                <div key={data.name} className="flex items-center justify-between p-2.5 bg-warm-bg/30 border border-sage/10 rounded-2xl">
                  <div className="flex items-center space-x-2.5">
                    <span className="text-lg">{data.emoji}</span>
                    <div>
                      <p className="text-xs font-bold text-sage">{data.name}</p>
                      <p className="text-[10px] text-zinc-400 font-medium font-serif">{data.count} টি বাণী সংরক্ষিত</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold font-serif" style={{ color: data.color }}>
                      {data.percentage}%
                    </p>
                    <div className="w-16 h-1 bg-zinc-100 rounded-full overflow-hidden mt-1">
                      <div 
                        className="h-full rounded-full transition-all duration-500" 
                        style={{ width: `${data.percentage}%`, backgroundColor: data.color }} 
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-7 h-48 md:h-52 w-full flex items-center justify-center relative">
          <ResponsiveContainer width="99%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
            >
              <XAxis 
                dataKey="name" 
                tick={{ fill: darkMode ? '#CECEB9' : '#5A5A40', fontSize: 11, fontWeight: 'medium' }}
                axisLine={{ stroke: darkMode ? 'rgba(206, 206, 185, 0.15)' : '#e4e4e7' }}
                tickLine={false}
              />
              <YAxis 
                allowDecimals={false}
                tick={{ fill: darkMode ? '#9C9C8E' : '#8b8b8b', fontSize: 10, fontFamily: 'serif' }}
                axisLine={{ stroke: darkMode ? 'rgba(206, 206, 185, 0.15)' : '#e4e4e7' }}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: darkMode ? 'rgba(206, 206, 185, 0.04)' : 'rgba(90, 90, 64, 0.04)' }} />
              <Bar 
                dataKey="count" 
                radius={[8, 8, 0, 0]} 
                maxBarSize={44}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  // Dark mode theme states
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  // Application states
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<ReligionFilter>('all');
  const [results, setResults] = useState<ScriptureResult[]>([]);
  const [aiReply, setAiReply] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'search' | 'journal' | 'flutter-code'>('search');
  
  // Reflection journal states
  const [savedItems, setSavedItems] = useState<SavedScriptureItem[]>([]);
  const [selectedForNote, setSelectedForNote] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');
  
  // UI interaction states
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingText, setSpeakingText] = useState<string | null>(null);
  const [isCopiedCode, setIsCopiedCode] = useState(false);
  const [activeShareId, setActiveShareId] = useState<string | null>(null);
  const [shareStatusMsg, setShareStatusMsg] = useState<string | null>(null);

  // Sync saved reflections with localStorage
  useEffect(() => {
    const localSaved = localStorage.getItem('scripture_reflections');
    if (localSaved) {
      try {
        setSavedItems(JSON.parse(localSaved));
      } catch (e) {
        console.error('Error parsing reflections data:', e);
      }
    }
  }, []);

  const saveReflectionsToLocal = (newItems: SavedScriptureItem[]) => {
    setSavedItems(newItems);
    localStorage.setItem('scripture_reflections', JSON.stringify(newItems));
  };

  // Search API execution
  const handleSearch = async (searchQuery: string, searchFilter: ReligionFilter) => {
    const q = searchQuery.trim();
    if (!q) {
      setError('অনুগ্রহ করে অনুসন্ধানের জন্য কোনো বিষয় বা মূলশব্দ লিখুন।');
      return;
    }

    setLoading(true);
    setError(null);
    setAiReply(null); // Reset previous reply immediately during loading
    try {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonStringifyForSearch(q, searchFilter),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'বাণী অনুসন্ধান করা সম্ভব হয়নি। অনুগ্রহ করে পুনরায় চেষ্টা করুন।');
      }

      const data = await response.json();
      setResults(data.results || []);
      setAiReply(data.ai_reply || null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'পরিসেবা সংযোগ বিচ্ছিন্ন। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  const jsonStringifyForSearch = (q: string, f: ReligionFilter) => {
    return JSON.stringify({
      query: q,
      religion: f
    });
  };

  // Clipboard copy functions
  const copyToClipboard = (text: string, reference: string, id: string) => {
    const shareableText = `"${text}"\n— ${reference}\n\n(ঐশী বাণী অনুসন্ধান অ্যাপ থেকে)`;
    navigator.clipboard.writeText(shareableText);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const copyFlutterCode = () => {
    navigator.clipboard.writeText(flutterSourceCode);
    setIsCopiedCode(true);
    setTimeout(() => setIsCopiedCode(false), 2000);
  };

  // Share Formatting and Actions
  const getShareDetails = (verseText: string, religion: string, source: string, refNum: string) => {
    const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-uxmxrvnoulsyhtvrn2ek46-531028043672.asia-northeast1.run.app';
    const appUrl = (currentUrl.includes('localhost') || currentUrl.includes('127.0.0.1'))
      ? 'https://ais-pre-uxmxrvnoulsyhtvrn2ek46-531028043672.asia-northeast1.run.app'
      : currentUrl;
      
    const religionEmoji = religion === 'Islam' 
      ? '🕌' 
      : religion === 'Sanatan' 
        ? '🕉️' 
        : religion === 'Christianity' 
          ? '✝️' 
          : '☸️';

    const religionText = religion === 'Islam' 
      ? 'ইসলামী বাণী' 
      : religion === 'Sanatan' 
        ? 'সনাতন বাণী/শ্লোক' 
        : religion === 'Christianity' 
          ? 'খ্রিষ্টধর্ম উপদেশ' 
          : 'বৌদ্ধ বাণী ও প্রজ্ঞা';

    const verseTextClean = verseText.trim();
    const textSnippet = `✨ ${religionEmoji} ${religionText} ✨\n\n"${verseTextClean}"\n\n— ${source} (${refNum})\n\nঐশী বাণী পড়তে এবং নিজের আধ্যাত্মিক ডায়েরি ডায়েরি লিখতে ভিজিট করুন বা অ্যাপ ডাউনলোড করুন:\n👉 ${appUrl}`;
    return { textSnippet, appUrl };
  };

  const handleWhatsAppShare = (verseClean: string, religion: string, source: string, refNum: string) => {
    const { textSnippet } = getShareDetails(verseClean, religion, source, refNum);
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(textSnippet)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleTwitterShare = (verseClean: string, religion: string, source: string, refNum: string) => {
    const { textSnippet } = getShareDetails(verseClean, religion, source, refNum);
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(textSnippet)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleFacebookShare = (verseClean: string, religion: string, source: string, refNum: string) => {
    const { textSnippet, appUrl } = getShareDetails(verseClean, religion, source, refNum);
    
    navigator.clipboard.writeText(textSnippet).catch(err => {
      console.error('Could not copy text for Facebook share', err);
    });

    setShareStatusMsg("পোস্টের লেখাটি কপি করা হয়েছে! ফেসবুকে পোস্ট তৈরির সময় পেস্ট (Paste) করতে পারবেন।");
    
    setTimeout(() => {
      const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(appUrl)}`;
      window.open(url, '_blank', 'noopener,noreferrer');
    }, 400);

    setTimeout(() => {
      setShareStatusMsg(null);
    }, 5000);
  };

  // TTS Reader
  const speakText = (text: string, id: string) => {
    if ('speechSynthesis' in window) {
      if (speakingText === id) {
        window.speechSynthesis.cancel();
        setSpeakingText(null);
        return;
      }

      window.speechSynthesis.cancel();
      
      // Clean up text for clearer speech synthesis phrasing
      const cleanText = text.trim();
      const utterance = new SpeechSynthesisUtterance(cleanText);
      
      // Explicitly set language to Bengali (Bangladesh) by default so browser understands the script
      utterance.lang = 'bn-BD';
      utterance.rate = 0.95; // slightly slower for pleasant and clear spiritual speech pacing
      utterance.pitch = 1.0;
      
      // Retrieve available TTS voices installed on the device
      const voices = window.speechSynthesis.getVoices();
      
      // Find Bengali voice specifically (matching bn-BD, bn-IN, or general bengali)
      // We avoid general "IN"/"in" matching since that picks up English-India (en-IN) or Hindi (hi-IN)
      // which reads Bengali text as English/Hindi gibberish.
      let bengaliVoice = voices.find(v => v.lang === 'bn-BD' || v.lang === 'bn_BD');
      if (!bengaliVoice) {
        bengaliVoice = voices.find(v => v.lang.toLowerCase().startsWith('bn') || v.name.toLowerCase().includes('bengali'));
      }
      
      if (bengaliVoice) {
        utterance.voice = bengaliVoice;
        utterance.lang = bengaliVoice.lang;
      } else {
        // Fallback to setting lang strictly to 'bn-BD' if explicit voice object is not found
        utterance.lang = 'bn-BD';
      }
      
      utterance.onend = () => {
        setSpeakingText(null);
      };
      utterance.onerror = (e) => {
        console.error('TTS Playback Error:', e);
        setSpeakingText(null);
      };

      setSpeakingText(id);
      window.speechSynthesis.speak(utterance);
    } else {
      alert('দুঃখিত, আপনার ব্রাউজারটি Text-to-Speech সমর্থন করে না।');
    }
  };

  // Add search output cards to journal 
  const saveItemToReflections = (item: ScriptureResult) => {
    const isAlreadySaved = savedItems.some(saved => saved.id === item.id || (saved.verse_text === item.verse_text));
    if (isAlreadySaved) {
      // Remove it (toggle behavior)
      const updated = savedItems.filter(saved => !(saved.id === item.id || (saved.verse_text === item.verse_text)));
      saveReflectionsToLocal(updated);
    } else {
      const newItem: SavedScriptureItem = {
        ...item,
        savedAt: new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' }),
        personalNotes: ''
      };
      saveReflectionsToLocal([newItem, ...savedItems]);
    }
  };

  // Update personal notes inside Journal
  const handleSaveNotes = (id: string) => {
    const updated = savedItems.map(item => {
      if (item.id === id) {
        return { ...item, personalNotes: noteText };
      }
      return item;
    });
    saveReflectionsToLocal(updated);
    setSelectedForNote(null);
    setNoteText('');
  };

  // Delete journal reflections card
  const deleteReflection = (id: string) => {
    const updated = savedItems.filter(item => item.id !== id);
    saveReflectionsToLocal(updated);
  };

  return (
    <div className="min-h-screen bg-warm-bg science-grid text-warm-text font-sans flex flex-col justify-between selection:bg-sage/15 selection:text-sage relative overflow-hidden">
      
      {/* Top Bar Decoration ribbon */}
      <div className="h-1 bg-gradient-to-r from-emerald-500 via-gold to-rose-500 w-full relative z-30" />

      {/* Header Container */}
      <header className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full relative z-20">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          
          {/* Brand/Home Launcher - Clean & Respectful Multi-Faith Scripture Portal */}
          <div className="flex items-center space-x-4 cursor-pointer group" onClick={() => setActiveTab('search')}>
            <div className="bg-sage/95 text-white p-3 rounded-[16px] shadow-sm transform hover:scale-105 transition-all duration-300 relative border border-gold/15">
              <Atom className="h-8 w-8 text-[#2DD4BF] dark:text-sage animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <Sparkle className="h-3.5 w-3.5 text-gold fill-gold" />
                <span className="text-[10px] uppercase tracking-wider font-bold text-gold/95 bg-sage/10 px-2.5 py-0.5 rounded-lg border border-sage/10">তুলনামূলক ধর্মতত্ত্ব ও বাণী বিশ্লেষণ</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-black text-sage tracking-tight font-serif mt-1">ঐশী বাণী অনুসন্ধান</h1>
              <p className="text-[11px] font-sans text-sage/75 block mt-1 tracking-wide font-medium">ইসলাম ধর্ম • সনাতন ধর্ম • খ্রিস্টান ধর্ম • বৌদ্ধ ধর্ম</p>
            </div>
          </div>

          {/* Theme Toggle Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-3 bg-sage/5 hover:bg-sage/10 text-sage rounded-2xl border border-sage/10 cursor-pointer transition-all duration-300 hover:scale-105 active:scale-95 flex items-center justify-center shadow-3xs hover:border-sage/25 hover:text-gold"
              title={darkMode ? "লাইট মোড" : "ডার্ক মোড"}
              aria-label="Toggle Theme"
            >
              {darkMode ? <Sun className="h-5 w-5 text-gold" /> : <Moon className="h-5 w-5 text-sage" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Grid */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 w-full">
        
        {/* Tab 1: Live Scripture Search engine */}
        {activeTab === 'search' && (
          <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto">
            
            {/* Search Launcher Box */}
            <div className="bg-white rounded-[24px] border border-sage/20 p-6 md:p-8 shadow-sm space-y-6 relative overflow-hidden">
              
              <div className="space-y-2 relative z-10">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span className="text-sage text-xs font-semibold tracking-wide">ঐশী বাণী অনুসন্ধান ও বিশ্লেষণ</span>
                  </div>
                  
                  {/* Miniature diagnostic feedback bar */}
                  <div className="flex items-center gap-2 text-xs text-sage/70 font-sans">
                    <span className="flex items-center gap-1.5"><span className={`inline-block w-2.5 h-2.5 rounded-full ${loading ? 'bg-amber-500 animate-pulse' : 'bg-green-500'}`} /> {loading ? 'অনুসন্ধান ও বিশ্লেষণ চলছে...' : 'সংযুক্ত'}</span>
                    <span>|</span>
                    <span>রেফারেন্স: ১০০% যাচাইকৃত</span>
                  </div>
                </div>
                
                <h2 className="text-xl md:text-2xl font-bold font-serif text-[#4F4F38] dark:text-[#EFEFE5] pt-1">
                  যে বিষয়ে বাণী বা শ্লোক অনুসন্ধান করতে চান লিখুন
                </h2>
                <p className="text-xs text-warm-text/75 leading-relaxed">
                  রিয়েল-টাইম এআই স্পেকট্রোমেট্রি ইঞ্জিন সরাসরি ৪টি প্রধান ঐতিহাসিক ঐতিহ্য—<span className="font-semibold text-emerald-600 dark:text-emerald-400">ইসলাম (কুরআন, হাদিসবিডি-র ভেরিফাইড হাদিসসমগ্র ও সীরাত)</span>, <span className="font-semibold text-[#AE8E4E]">সনাতন ধর্ম (গীতা/বেদ/উপনিষদ)</span>, <span className="font-semibold text-rose-600 dark:text-rose-400">খ্রিষ্টধর্ম (বাইবেল)</span> এবং <span className="font-semibold text-amber-600 dark:text-amber-400">বৌদ্ধ ধর্ম (ত্রিপিটক/ধম্মপদ)</span> থেকে সত্যবাদী উদ্ধৃতি এবং নির্ভরযোগ্য রেফারেন্স লিংকসহ উপযুক্ত বাণী ও তত্ত্বীয় বিশ্লেষণ নিয়ে আসে।
                </p>
              </div>

              {/* Advanced System Parameter Dashboard hidden at user request */}

              {/* Filtering Controls hidden at user request */}

              {/* Main Search Input Form */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSearch(query, filter);
                }}
                className="relative z-10"
              >
                <div className="absolute left-4.5 top-4.5 text-sage/55 flex items-center pointer-events-none">
                  <Search className="h-5 w-5" />
                </div>
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="কোনো বিষয়ের নাম লিখুন (যেমন: ক্রোধ, ক্ষমা, পিতামাতা, অহংকার)..."
                  className="w-full text-sm font-sans font-medium placeholder-zinc-400 bg-warm-bg/30 text-warm-text border border-sage/20 focus:border-sage rounded-xl md:rounded-2xl pl-12 pr-28 py-4 outline-hidden transition-all shadow-input focus:bg-white focus:ring-4 focus:ring-sage/10"
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="absolute right-2 top-2 bottom-2 px-5 bg-sage hover:bg-sage/90 text-white rounded-lg md:rounded-xl transition-all cursor-pointer flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-xs active:scale-95 border border-gold/10 font-bold"
                >
                  {loading ? (
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <span className="text-xs font-sans">অনুসন্ধান করুন</span>
                  )}
                </button>
              </form>

              {/* suggestions box hidden at user request */}

            </div>

            {/* Error alerts indicator */}
            {error && (
              <div className="bg-red-50 border border-red-200/60 rounded-2xl p-4 flex items-center space-x-3 text-red-800 text-xs">
                <X className="h-5 w-5 text-red-600 shrink-0" onClick={() => setError(null)} />
                <p className="font-sans leading-relaxed">{error}</p>
              </div>
            )}

            {/* Loader display for Search results API */}
            {loading && (
              <div className="text-center py-20 bg-white rounded-xl border border-sage/15 shadow-sm space-y-4">
                <div className="relative inline-block w-16 h-16">
                  {/* Decorative rotating loader */}
                  <div className="absolute inset-0 border-4 border-sage/10 rounded-full" />
                  <div className="absolute inset-0 border-4 border-gold border-t-transparent rounded-full animate-spin" />
                  <Atom className="absolute inset-4 h-8 w-8 text-sage animate-pulse text-emerald-400" />
                </div>
                <div>
                  <h4 className="font-bold text-sage font-serif text-lg">ঐশ্বরিক জ্ঞানকোষ থেকে অনুসন্ধান করা হচ্ছে</h4>
                  <p className="text-xs text-zinc-400 mt-1 max-w-xs mx-auto font-sans leading-relaxed">Gemini 3.5 Flash পবিত্র বেদ, বাইবেল, আল-কুরআন ও গীতার মূল উৎস থেকে নির্ভরযোগ্য রেফারেন্স লাইভ খুঁজে আনছে।</p>
                </div>
              </div>
            )}

            {/* Render response output Scripture cards list */}
            {!loading && (results.length > 0 || !query) && (
              <div className="space-y-6">
                
                {/* Section title indicating featured scriptures or live results */}
                {results.length > 0 && (
                  <div className="flex items-center justify-between border-b border-sage/15 pb-2">
                    <h3 className="text-lg font-bold text-sage font-serif flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-gold" />
                      {`"${query}" বিষয়ক প্রাপ্ত বাণীসমূহ (${results.length}টি)`}
                    </h3>
                  </div>
                )}

                {/* AI Reply Card (Redesigned as clean synthesis summary) */}
                {results.length > 0 && aiReply && (
                  <div className="bg-sage/5 border border-sage/20 rounded-xl p-6 md:p-8 space-y-4 shadow-sm animate-fadeIn relative overflow-hidden">
                    
                    <div className="flex items-start md:items-center gap-3 relative z-10">
                      <div className="p-2.5 bg-gold/15 dark:bg-gold/20 text-[#AE8E4E] dark:text-gold rounded-xl shrink-0 flex items-center justify-center border border-gold/10">
                        <Sparkles className="h-5 w-5 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-serif font-bold text-[#4F4F38] dark:text-[#EFEFE5] text-base md:text-lg flex items-center gap-1.5 leading-tight">
                          সহানুভূতিশীল এআই বিশ্লেষণ ও তুলনামূলক প্রজ্ঞা
                        </h4>
                        <p className="text-[11px] text-sage/75 select-none font-medium">আন্তঃধর্মীয় তুলনামূলক নৈতিক বিশ্লেষণ ও সম্প্রীতির বার্তা</p>
                      </div>
                    </div>
                    
                    <div className="relative z-10 pt-1 border-t border-dashed border-sage/15 mt-3">
                      <p className="text-sm md:text-[15px] text-[#2D2D2A] dark:text-[#EFEFE5] font-serif leading-relaxed italic select-all md:whitespace-normal whitespace-pre-wrap pl-1 md:pl-2">
                        "{aiReply}"
                      </p>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(results.length > 0 ? results : localFeaturedScriptures).map((item, idx) => {
                    const isSaved = savedItems.some(saved => saved.id === item.id || saved.verse_text === item.verse_text);
                    
                    const badgeColor = item.religion === 'Islam' 
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200/60' 
                      : item.religion === 'Sanatan' 
                        ? 'bg-gold/10 text-[#7a5a40] border-gold/20' 
                        : item.religion === 'Christianity'
                          ? 'bg-rose-50 text-rose-800 border-rose-200/60'
                          : 'bg-amber-50 text-amber-800 border-amber-200/60';
                      
                    const ledClass = item.religion === 'Islam'
                      ? 'bg-emerald-500 led-active'
                      : item.religion === 'Sanatan'
                        ? 'bg-amber-500 led-gold'
                        : item.religion === 'Christianity'
                          ? 'bg-rose-500 led-active'
                          : 'bg-yellow-500 led-gold';

                    const religionLabel = item.religion === 'Islam' 
                      ? '🕌 ইসলাম' 
                      : item.religion === 'Sanatan' 
                        ? '🕉️ সনাতন' 
                        : item.religion === 'Christianity'
                          ? '✝️ খ্রিষ্টধর্ম'
                          : '☸️ বৌদ্ধধর্ম';

                    return (
                      <div 
                        key={`${item.id || 'search'}-${idx}`}
                        className="bg-white rounded-xl border border-sage/15 p-6 md:p-7 shadow-xs hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden group animate-fadeIn"
                      >

                        {/* Top Meta info */}
                        <div className="space-y-4">
                          
                          <div className="flex items-center justify-between pt-1">
                            <span className={`text-xs px-2.5 py-0.5 rounded-md border font-bold flex items-center gap-1.5 ${badgeColor}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${ledClass}`} />
                              {religionLabel}
                            </span>
                            <span className="text-xs text-sage/70 font-semibold font-sans">
                              বিষয়: {item.topic}
                            </span>
                          </div>

                          {/* Arabic text & Pronunciation block */}
                          {item.arabic_text && (
                            <div className="bg-emerald-50/25 rounded-2xl p-4.5 border border-emerald-500/15 space-y-2.5 leading-relaxed text-right" dir="rtl">
                              <p className="font-serif text-[21px] text-emerald-950 font-bold leading-loose tracking-wide select-all">
                                {item.arabic_text}
                              </p>
                              {item.arabic_pronunciation && (
                                <p dir="ltr" className="text-left text-xs text-emerald-800/90 font-sans font-medium pt-2 border-t border-emerald-500/10 mt-1 select-text">
                                  <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded mr-1.5 inline-block select-none">উচ্চারণ:</span>
                                  <span>{item.arabic_pronunciation}</span>
                                </p>
                              )}
                            </div>
                          )}

                          {/* Verse Quote text section */}
                          <blockquote className="relative">
                            <span className="absolute -top-3.5 -left-4 text-4xl text-sage/10 font-serif font-bold">“</span>
                            <p className="font-serif text-[17px] text-warm-text italic leading-relaxed font-semibold relative z-10">
                              {item.verse_text}
                            </p>
                          </blockquote>

                          {/* Reference Number address */}
                          <div className="flex justify-end items-center gap-2 pt-1 flex-wrap">
                            <p className="text-xs text-sage font-bold font-serif">
                              — {item.source_chapter} ({item.reference_number})
                            </p>
                            {item.reference_link && (
                              <a 
                                href={item.reference_link} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-[10px] text-gold hover:text-gold/80 font-bold bg-gold/5 hover:bg-gold/10 px-2 py-0.5 rounded-lg border border-gold/15 inline-flex items-center gap-1 cursor-pointer transition-all font-sans"
                                title="মূল গ্রন্থ থেকে রেফারেন্স যাচাই করুন"
                              >
                                🔗 উৎস দেখুন
                              </a>
                            )}
                          </div>
                        </div>

                        {/* Context brief explanation block */}
                        <div className="mt-5 pt-4 border-t border-sage/10 space-y-3">
                          <div className="bg-warm-bg/40 rounded-2xl p-4 border border-sage/5 flex items-start gap-2.5">
                            <div className="p-1 bg-white rounded-lg text-gold shadow-3xs shrink-0">
                              <Sparkles className="h-3.5 w-3.5" />
                            </div>
                            <p className="text-xs text-warm-text/90 italic leading-relaxed font-sans font-medium">
                              {item.context_explanation}
                            </p>
                          </div>

                          {/* Interactions Toolbar: Copy, Speak, Save */}
                          <div className="flex items-center justify-between text-zinc-400 pt-2 border-t border-sage/5 flex-wrap gap-2">
                            <div className="flex space-x-1.5">
                              {/* Copy trigger */}
                              <button
                                onClick={() => copyToClipboard(item.verse_text, `${item.source_chapter} (${item.reference_number})`, item.id || idx.toString())}
                                className="p-2.5 hover:bg-sage/10 text-sage/75 hover:text-sage rounded-xl cursor-pointer transition-all flex items-center gap-1.5 text-xs font-semibold"
                                title="কপি করুন"
                              >
                                {copiedId === (item.id || idx.toString()) ? (
                                  <>
                                    <Check className="h-4 w-4 text-emerald-600" />
                                    <span className="text-emerald-700">কপিড!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="h-4 w-4" />
                                    <span>কপি</span>
                                  </>
                                )}
                              </button>

                              {/* TTS speak aloud */}
                              <button
                                onClick={() => speakText(item.verse_text, item.id || idx.toString())}
                                className={`p-2.5 hover:bg-sage/10 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 text-xs font-semibold ${
                                  speakingText === (item.id || idx.toString()) 
                                    ? 'text-gold bg-gold/10' 
                                    : 'text-sage/75 hover:text-sage'
                                }`}
                                title="স্বরের মাধ্যমে শুনুন"
                              >
                                {speakingText === (item.id || idx.toString()) ? (
                                  <>
                                    <VolumeX className="h-4 w-4" />
                                    <span className="text-gold font-bold animate-pulse">থামুন</span>
                                  </>
                                ) : (
                                  <>
                                    <Volume2 className="h-4 w-4" />
                                    <span>শুনুন</span>
                                  </>
                                )}
                              </button>

                              {/* Share Popover trigger */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const cardId = item.id || idx.toString();
                                  setActiveShareId(activeShareId === cardId ? null : cardId);
                                }}
                                className={`p-2.5 hover:bg-sage/10 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 text-xs font-semibold ${
                                  activeShareId === (item.id || idx.toString())
                                    ? 'text-gold bg-gold/10'
                                    : 'text-sage/75 hover:text-sage'
                                }`}
                                title="শেয়ার করুন"
                                id={`share-btn-${item.id || idx}`}
                              >
                                <Share2 className="h-4 w-4" />
                                <span>শেয়ার</span>
                              </button>
                            </div>

                            {/* Save/Wishlist Trigger hidden at user request */}
                          </div>

                          {/* Pre-formatted Share Panel */}
                          {activeShareId === (item.id || idx.toString()) && (
                            <div className="mt-4 p-4 bg-warm-bg/50 border border-gold/15 rounded-2xl space-y-3.5 animate-fadeIn relative z-15">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-sage flex items-center gap-1.5">
                                  <Sparkles className="h-3.5 w-3.5 text-gold" />
                                  শেয়ার করার প্রি-ফরম্যাটেড স্নীপেট
                                </span>
                                <button 
                                  onClick={() => setActiveShareId(null)}
                                  className="text-zinc-400 hover:text-zinc-600 p-0.5 rounded-full hover:bg-zinc-100 cursor-pointer transition-all"
                                  title="বন্ধ করুন"
                                >
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              </div>
                              
                              <div className="bg-white border border-sage/10 rounded-xl p-3 text-[11px] font-sans leading-relaxed text-warm-text/90 max-h-24 overflow-y-auto whitespace-pre-line shadow-inner">
                                {getShareDetails(item.verse_text, item.religion, item.source_chapter, item.reference_number).textSnippet}
                              </div>

                              <div className="grid grid-cols-3 gap-2">
                                {/* WhatsApp */}
                                <button
                                  onClick={() => handleWhatsAppShare(item.verse_text, item.religion, item.source_chapter, item.reference_number)}
                                  className="flex flex-col items-center justify-center p-2.5 bg-emerald-50 hover:bg-[#25D366]/10 text-emerald-800 border-emerald-200/50 rounded-xl transition-all border border-emerald-200 cursor-pointer text-xs"
                                >
                                  <span className="text-lg mb-1">💬</span>
                                  <span>WhatsApp</span>
                                </button>

                                {/* Facebook */}
                                <button
                                  onClick={() => handleFacebookShare(item.verse_text, item.religion, item.source_chapter, item.reference_number)}
                                  className="flex flex-col items-center justify-center p-2.5 bg-blue-50 hover:bg-[#1877F2]/10 text-blue-800 border-blue-200/50 rounded-xl transition-all border border-blue-200 cursor-pointer text-xs"
                                >
                                  <span className="text-lg mb-1">📘</span>
                                  <span>Facebook</span>
                                </button>

                                {/* Twitter/X */}
                                <button
                                  onClick={() => handleTwitterShare(item.verse_text, item.religion, item.source_chapter, item.reference_number)}
                                  className="flex flex-col items-center justify-center p-2.5 bg-zinc-50 hover:bg-zinc-100 text-zinc-900 border-zinc-200 rounded-xl transition-all border border-zinc-200 cursor-pointer text-xs"
                                >
                                  <span className="text-lg mb-1">🐦</span>
                                  <span>Twitter</span>
                                </button>
                              </div>

                              {shareStatusMsg && activeShareId === (item.id || idx.toString()) && (
                                <p className="text-[10px] text-emerald-800 font-bold bg-emerald-50 border border-emerald-200/50 px-2.5 py-1.5 rounded-lg animate-fadeIn text-center">
                                  {shareStatusMsg}
                                </p>
                              )}
                            </div>
                          )}

                        </div>

                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Spiritual Reflections Journal (আত্মিক চিন্তা জার্নাল) */}
        {activeTab === 'journal' && (
          <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
            
            {/* Header info bar */}
            <div className="bg-gradient-to-tr from-sage/10 to-gold/5 p-6 rounded-[32px] border border-sage/15 shadow-3xs">
              <div className="flex items-center space-x-4">
                <div className="bg-sage text-white p-3 rounded-2xl shadow-xs">
                  <BookMarked className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-sage font-serif">আপনার আত্মিক চিন্তা জার্নাল</h3>
                  <p className="text-sm text-warm-text/80 mt-1 font-sans">পবিত্র বাণী এবং প্রতিফলনের মাধ্যমে নিজের চিন্তা লিপিবদ্ধ রাখুন। এই সমস্ত রেকর্ড সম্পূর্ণ নিরাপদ আপনার স্থানীয় ব্রাউজারে সংরক্ষিত থাকে।</p>
                </div>
              </div>
            </div>

            {/* Recharts summary stats if reflections exist */}
            {savedItems.length > 0 && (
              <JournalStatsChart savedItems={savedItems} darkMode={darkMode} />
            )}

            {/* If empty saved items */}
            {savedItems.length === 0 ? (
              <div className="text-center py-24 bg-white rounded-[32px] border border-sage/15 space-y-4 shadow-3xs">
                <div className="inline-flex p-4 bg-warm-bg rounded-full text-sage/60">
                  <Bookmark className="h-8 w-8" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-sage">এখনো কোনো বাণী জার্নালে যুক্ত করা হয়নি</h4>
                  <p className="text-sm text-zinc-400 mt-1 max-w-xs mx-auto font-sans">বাণী অনুসন্ধান করার সময় ডানদিকের "জার্নাল ও নোট" বাটনে ক্লিক করে পবিত্র বাণীসমূহ আপনার ব্যক্তিগত খাতায় যুক্ত করুন।</p>
                </div>
                <button
                  onClick={() => setActiveTab('search')}
                  className="px-6 py-3 bg-sage hover:bg-sage/90 text-white rounded-full text-sm font-bold shadow-xs cursor-pointer transition-all"
                >
                  বাণী খুঁজতে চলুন
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {savedItems.map((item, idx) => {
                  const badgeStyle = item.religion === 'Islam' 
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200/60' 
                    : item.religion === 'Sanatan' 
                      ? 'bg-gold/10 text-[#7a5a40] border-gold/20' 
                      : item.religion === 'Christianity'
                        ? 'bg-rose-50 text-rose-800 border-rose-200/60'
                        : 'bg-amber-50 text-amber-800 border-amber-200/60';

                  const journalReligionLabel = item.religion === 'Islam' 
                    ? '🕌 ইসলাম' 
                    : item.religion === 'Sanatan' 
                      ? '🕉️ সনাতন' 
                      : item.religion === 'Christianity'
                        ? '✝️ খ্রিষ্টধর্ম'
                        : '☸️ বৌদ্ধধর্ম';

                  return (
                    <div 
                      key={`${item.id}-${idx}`}
                      className="bg-white rounded-[32px] border border-sage/15 p-6 md:p-8 shadow-xs hover:shadow-sm transition-all relative flex flex-col md:flex-row gap-6 animate-fadeIn"
                    >
                      {/* Left side detail */}
                      <div className="flex-1 space-y-3.5">
                        <div className="flex items-center space-x-2">
                          <span className={`text-xs px-2.5 py-0.5 rounded-full border font-bold ${badgeStyle}`}>
                            {journalReligionLabel}
                          </span>
                          <span className="text-[11px] text-sage/60 font-medium">যুক্ত করা হয়েছে: {item.savedAt}</span>
                        </div>

                        {/* Arabic text & Pronunciation block for saved reflections */}
                        {item.arabic_text && (
                          <div className="bg-emerald-50/25 rounded-2xl p-4 md:p-5 border border-emerald-500/10 space-y-2 leading-relaxed text-right md:text-right" dir="rtl">
                            <p className="font-serif text-[20px] text-emerald-950 font-bold leading-loose tracking-wide select-all">
                              {item.arabic_text}
                            </p>
                            {item.arabic_pronunciation && (
                              <p dir="ltr" className="text-left text-xs text-emerald-800/90 font-sans font-medium pt-2 border-t border-emerald-500/10 mt-1 select-text">
                                <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded mr-1.5 inline-block select-none">উচ্চারণ:</span>
                                <span>{item.arabic_pronunciation}</span>
                              </p>
                            )}
                          </div>
                        )}

                        <blockquote className="font-serif text-lg text-warm-text italic font-medium leading-relaxed">
                          " {item.verse_text} "
                        </blockquote>

                        <div className="flex justify-end items-center gap-2 pt-1 flex-wrap">
                          <p className="text-xs text-sage font-bold font-serif">
                            — {item.source_chapter} ({item.reference_number})
                          </p>
                          {item.reference_link && (
                            <a 
                              href={item.reference_link} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-[10px] text-gold hover:text-gold/80 font-bold bg-gold/5 hover:bg-gold/10 px-2 py-0.5 rounded-lg border border-gold/15 inline-flex items-center gap-1 cursor-pointer transition-all font-sans"
                              title="মূল গ্রন্থ থেকে রেফারেন্স যাচাই করুন"
                            >
                              🔗 উৎস দেখুন
                            </a>
                          )}
                        </div>

                        {/* Interactions Toolbar in Journal card */}
                        <div className="flex items-center gap-1.5 pt-3 border-t border-sage/10 text-zinc-400">
                          {/* Copy trigger */}
                          <button
                            onClick={() => copyToClipboard(item.verse_text, `${item.source_chapter} (${item.reference_number})`, item.id)}
                            className="p-2.5 hover:bg-sage/10 text-sage/75 hover:text-sage rounded-xl cursor-pointer transition-all flex items-center gap-1.5 text-xs font-semibold"
                            title="কপি করুন"
                          >
                            {copiedId === item.id ? (
                              <>
                                <Check className="h-4 w-4 text-emerald-600" />
                                <span className="text-emerald-700">কপিড!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="h-4 w-4" />
                                <span>কপি</span>
                              </>
                            )}
                          </button>

                          {/* TTS speak aloud */}
                          <button
                            onClick={() => speakText(item.verse_text, item.id)}
                            className={`p-2.5 hover:bg-sage/10 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 text-xs font-semibold ${
                              speakingText === item.id 
                                ? 'text-gold bg-gold/10' 
                                : 'text-sage/75 hover:text-sage'
                            }`}
                            title="স্বরের মাধ্যমে শুনুন"
                          >
                            {speakingText === item.id ? (
                              <>
                                <VolumeX className="h-4 w-4" />
                                <span className="text-gold font-bold animate-pulse">থামুন</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="h-4 w-4" />
                                <span>শুনুন</span>
                              </>
                            )}
                          </button>

                          {/* Share Popover trigger */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveShareId(activeShareId === item.id ? null : item.id);
                            }}
                            className={`p-2.5 hover:bg-sage/10 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 text-xs font-semibold ${
                              activeShareId === item.id
                                ? 'text-gold bg-gold/10'
                                : 'text-sage/75 hover:text-sage'
                            }`}
                            title="শেয়ার করুন"
                            id={`journal-share-btn-${item.id}`}
                          >
                            <Share2 className="h-4 w-4" />
                            <span>শেয়ার</span>
                          </button>
                        </div>

                        {/* Share Panel in Journal card */}
                        {activeShareId === item.id && (
                          <div className="mt-3 p-4 bg-warm-bg/50 border border-gold/15 rounded-2xl space-y-3 animate-fadeIn relative z-15">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-sage flex items-center gap-1.5">
                                <Sparkles className="h-3.5 w-3.5 text-gold" />
                                ডায়েরি থেকে বাণী শেয়ার করুন
                              </span>
                              <button 
                                onClick={() => setActiveShareId(null)}
                                className="text-zinc-400 hover:text-zinc-600 p-0.5 rounded-full hover:bg-zinc-100 cursor-pointer transition-all"
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            
                            <div className="bg-white border border-sage/10 rounded-xl p-3 text-[11px] font-sans leading-relaxed text-warm-text/90 max-h-24 overflow-y-auto whitespace-pre-line shadow-inner">
                              {getShareDetails(item.verse_text, item.religion, item.source_chapter, item.reference_number).textSnippet}
                            </div>

                            <div className="grid grid-cols-3 gap-2">
                              {/* WhatsApp */}
                              <button
                                onClick={() => handleWhatsAppShare(item.verse_text, item.religion, item.source_chapter, item.reference_number)}
                                className="flex flex-col items-center justify-center p-2.5 bg-emerald-50 hover:bg-[#25D366]/10 text-emerald-800 border-emerald-200/50 rounded-xl transition-all border border-emerald-200 cursor-pointer text-xs"
                              >
                                <span className="text-lg mb-1">💬</span>
                                <span>WhatsApp</span>
                              </button>

                              {/* Facebook */}
                              <button
                                onClick={() => handleFacebookShare(item.verse_text, item.religion, item.source_chapter, item.reference_number)}
                                className="flex flex-col items-center justify-center p-2.5 bg-blue-50 hover:bg-[#1877F2]/10 text-blue-800 border-blue-200/50 rounded-xl transition-all border border-blue-200 cursor-pointer text-xs"
                              >
                                <span className="text-lg mb-1">📘</span>
                                <span>Facebook</span>
                              </button>

                              {/* Twitter/X */}
                              <button
                                onClick={() => handleTwitterShare(item.verse_text, item.religion, item.source_chapter, item.reference_number)}
                                className="flex flex-col items-center justify-center p-2.5 bg-zinc-50 hover:bg-zinc-100 text-zinc-900 border-zinc-200 rounded-xl transition-all border border-zinc-200 cursor-pointer text-xs"
                              >
                                <span className="text-lg mb-1">🐦</span>
                                <span>Twitter</span>
                              </button>
                            </div>

                            {shareStatusMsg && activeShareId === item.id && (
                              <p className="text-[10px] text-emerald-800 font-bold bg-emerald-50 border border-emerald-200/50 px-2.5 py-1.5 rounded-lg animate-fadeIn text-center">
                                {shareStatusMsg}
                              </p>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Right side editable reflection card */}
                      <div className="w-full md:w-80 border-t md:border-t-0 md:border-l border-sage/10 pt-5 md:pt-0 md:pl-6 flex flex-col justify-between">
                        
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-sage/70 flex items-center gap-1 font-sans">
                              <PenSquare className="h-3.5 w-3.5" />
                              আপনার ব্যক্তিগত প্রতিফলন:
                            </span>

                            {selectedForNote !== item.id && item.personalNotes && (
                              <button
                                onClick={() => {
                                  setSelectedForNote(item.id);
                                  setNoteText(item.personalNotes || '');
                                }}
                                className="text-xs text-gold hover:text-gold/95 font-semibold cursor-pointer font-sans"
                              >
                                এডিট করুন
                              </button>
                            )}
                          </div>

                          {selectedForNote === item.id ? (
                            <div className="space-y-2">
                              <textarea
                                value={noteText}
                                onChange={(e) => setNoteText(e.target.value)}
                                placeholder="এই পবিত্র বাণীর প্রেক্ষিতে আপনার আত্মিক অনুভাব, উপলব্ধি বা প্রার্থনা লিখুন..."
                                className="w-full border border-sage/25 rounded-2xl p-3 text-xs bg-warm-bg/30 text-warm-text font-serif italic focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-sage/20 h-24 text-[13px]"
                              />
                              <div className="flex justify-end gap-1.5 font-sans">
                                <button
                                  onClick={() => setSelectedForNote(null)}
                                  className="px-3 py-1.5 bg-warm-bg hover:bg-sage/10 text-sage rounded-lg text-[11px] font-bold cursor-pointer transition-all"
                                >
                                  বাতিল
                                </button>
                                <button
                                  onClick={() => handleSaveNotes(item.id)}
                                  className="px-3 py-1.5 bg-sage hover:bg-sage/90 text-white rounded-lg text-[11px] font-bold cursor-pointer transition-all"
                                >
                                  সংরক্ষণ
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="bg-warm-bg/30 border border-sage/10 rounded-2xl p-3 h-24 overflow-y-auto">
                              {item.personalNotes ? (
                                <p className="text-xs text-warm-text/90 font-serif italic leading-relaxed font-medium">{item.personalNotes}</p>
                              ) : (
                                <div className="h-full flex flex-col items-center justify-center text-center">
                                  <p className="text-xs text-zinc-400 italic font-sans animate-fadeIn">কোনো ব্যক্তিগত চিন্তাভাবনা যুক্ত করা নেই</p>
                                  <button
                                    onClick={() => {
                                      setSelectedForNote(item.id);
                                      setNoteText('');
                                    }}
                                    className="text-xs text-gold hover:text-gold/90 font-bold inline-flex items-center gap-0.5 mt-1 cursor-pointer font-sans"
                                  >
                                    <Plus className="h-3 w-3" />
                                    নোট লিখুন
                                  </button>
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Delete trigger */}
                        <div className="flex justify-end mt-4 pt-3 border-t border-sage/10 font-sans">
                          <button
                            onClick={() => deleteReflection(item.id)}
                            className="text-xs text-rose-600 hover:text-rose-700 font-semibold inline-flex items-center gap-1 hover:bg-rose-50/60 px-2 py-1.5 rounded-lg transition-all cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                            মুছে ফেলুন
                          </button>
                        </div>

                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Flutter production ready code tab */}
        {activeTab === 'flutter-code' && (
          <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
            
            {/* Header info card */}
            <div className="bg-sage text-white p-6 rounded-[32px] border border-sage/40 shadow-xs relative overflow-hidden">
              <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gradient-to-tr from-white/10 via-gold/10 to-transparent rounded-full -z-0 pointer-events-none" />
              <div className="flex items-center space-x-4 relative z-10">
                <div className="bg-white/15 p-3 rounded-2xl">
                  <FileCode className="h-7 w-7 text-gold" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold font-serif">Flutter মোবাইল অ্যাপ সোর্স কোড (`main.dart`)</h3>
                  <p className="text-sm text-yellow-50/90 mt-1 font-sans">
                    আপনার অনুরোধ অনুযায়ী ইসলাম, সনাতন ও খ্রিষ্টধর্মের পবিত্র গ্রন্থ অনুসন্ধানের একটি সম্পূর্ণ ফ্ল্যাটার বিগ이너-ফ্রেন্ডলি চমৎকার মোবাইল অ্যাপ কোড।
                  </p>
                </div>
              </div>
            </div>

            {/* Instruction Panel */}
            <div className="bg-white border border-sage/15 rounded-[32px] p-6 space-y-3 shadow-xs">
              <h4 className="font-bold text-sage flex items-center gap-1.5 font-serif">
                <span className="text-gold">📌</span>
                ফ্লুটারে এটি কিভাবে ব্যবহার করবেন:
              </h4>
              <ul className="text-xs text-warm-text/85 space-y-2 list-decimal pl-5 font-sans">
                <li>আপনার Flutter প্রকল্পে <strong>pubspec.yaml</strong> ফাইলে ডিপেনডেন্সি বিভাগে <code className="bg-warm-bg text-[#7a5a40] px-1.5 py-0.5 font-mono rounded-md">http: ^1.1.0</code> যুক্ত করে <code className="bg-warm-bg text-[#5A5A40] px-1.5 py-0.5 font-mono rounded-md">flutter pub get</code> চালনা করুন।</li>
                <li>নিচের কোডটি সম্পূর্ণ কপি করে আপনার অ্যাপের <strong>lib/main.dart</strong> ফাইলে পেস্ট করে দিন।</li>
                <li>কোডের ভেতর <code className="bg-warm-bg text-[#5A5A40] px-1.5 py-0.5 font-mono rounded-md">_backendBaseUrl</code> ভ্যারিয়েবল চিহ্নিত অংশে আপনার এই লাইভ হোস্ট করা অ্যাপ্লিকেশনের URL বসিয়ে দিন যাতে আপনার লোকাল মোবাইল অথবা এমুলেটর সরাসরি এই Gemini API গেটওয়ে সংযোগে কল করতে পারে!</li>
              </ul>
            </div>

            {/* Simulated VS Code code browser */}
            <div className="bg-zinc-900 rounded-[32px] border border-sage/25 shadow-md relative overflow-hidden flex flex-col h-[500px]">
              
              {/* Header Editor Controls */}
              <div className="bg-zinc-950 px-5 py-3.5 flex items-center justify-between border-b border-zinc-800">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1.5">
                    <span className="w-3.5 h-3.5 rounded-full bg-rose-500 inline-block" />
                    <span className="w-3.5 h-3.5 rounded-full bg-amber-500 inline-block" />
                    <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 inline-block" />
                  </div>
                  <span className="text-zinc-400 text-xs font-mono pl-3">main.dart — Flutter Production Ready Code</span>
                </div>

                {/* Copy button */}
                <button
                  onClick={copyFlutterCode}
                  className="px-4 py-2 bg-sage hover:bg-sage/85 text-white text-xs font-bold rounded-xl cursor-pointer transition-all flex items-center gap-1.5 active:scale-[0.98]"
                >
                  {isCopiedCode ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      <span>অনুলিপি করা হয়েছে!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>কোড কপি করুন</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code Panel */}
              <div className="flex-1 overflow-auto p-5 font-mono text-xs text-zinc-300 leading-relaxed bg-[#0F172A] selection:bg-sage/35 selection:text-white">
                <pre>{flutterSourceCode}</pre>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Aesthetic Footer area */}
      <footer className="border-t border-sage/15 bg-white/50 backdrop-blur-3xs mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-sage/75 text-xs gap-4 font-sans">
          <div>
            <p className="font-semibold text-emerald-700 dark:text-[#2DD4BF]">অ্যাপ নির্মাতা: কো কিম (Ko Kim)</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
