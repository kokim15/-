/**
 * Type definitions for Multi-Faith Scripture Search App
 */

export interface ScriptureResult {
  id: string;
  religion: 'Islam' | 'Sanatan' | 'Christianity' | 'Buddhism';
  topic: string;
  verse_text: string;
  source_chapter: string;
  reference_number: string;
  context_explanation: string;
  reference_link?: string;
  arabic_text?: string;
  arabic_pronunciation?: string;
}

export type ReligionFilter = 'all' | 'islam' | 'sanatan' | 'christianity' | 'buddhism';

export interface SavedScriptureItem extends ScriptureResult {
  savedAt: string;
  personalNotes?: string;
}
